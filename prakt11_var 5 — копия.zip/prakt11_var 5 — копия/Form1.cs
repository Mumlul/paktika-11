﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prakt11_var_5
{
    public partial class Form1 :Form
    {
        public Form1 ()
        {
            InitializeComponent();
        }
        int step = 1;
       
        
      
        private void comboBox1_SelectedIndexChanged (object sender, EventArgs e)
        {
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                case 1:
                case 2:
                case 4:
                    label5.Visible = false;
                    textBox5.Visible = false;
                    label4.Visible = true;
                    textBox4.Visible = true;
                    label3.Visible = true;
                    textBox3.Visible = true;
                    break;
                case 3:label5.Visible = true;
                    textBox5.Visible = true;
                    label4.Visible = false;
                    textBox4.Visible = false;
                    label3.Visible = false;
                    textBox3.Visible = false;
                    break;
            }
        }

        private void button1_Click_1 (object sender, EventArgs e)
        {
            textBox1.Text.Replace(',', '.');
            textBox2.Text.Replace(',', '.');
            textBox3.Text.Replace(',', '.');
            textBox4.Text.Replace(',', '.');
            double a = Convert.ToDouble(textBox1.Text);
            double b = Convert.ToDouble(textBox2.Text);
            double a2 = Convert.ToDouble(textBox4.Text);
            double b2 = Convert.ToDouble(textBox3.Text);
            Kompl rez = new Kompl(a,b, a2, b2);
            
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    if(radioButton1.Checked)
                    MessageBox.Show(string.Format($"{rez.num1}\n{rez.num2}\n"+rez.minus(a, b, a2, b2)));
                    if (radioButton2.Checked)
                        MessageBox.Show(string.Format($"{rez.num1}\n{rez.num2}\n" + rez.trig(rez.minus(a, b, a2, b2))));
                    if (radioButton3.Checked)
                        MessageBox.Show(string.Format($"{rez.num1}\n{rez.num2}\n" + rez.ecspo(rez.minus(a, b, a2, b2))));
                    break;
                case 1:
                    if(radioButton1.Checked)
                    MessageBox.Show(string.Format($"{rez.num1}\n{rez.num2}\n" + rez.del(a, b, a2, b2)));
                    if(radioButton2.Checked)
                        MessageBox.Show(string.Format($"{rez.num1}\n{rez.num2}\n" + rez.trig(rez.del(a, b, a2, b2))));
                    if (radioButton3.Checked)
                        MessageBox.Show(string.Format($"{rez.num1}\n{rez.num2}\n" + rez.ecspo(rez.del(a, b, a2, b2))));
                    break;
                case 2:
                    if(radioButton1.Checked)
                    MessageBox.Show(string.Format($"{rez.num1}\n{rez.num2}\n" + rez.umn(a, b, a2, b2)));
                    if(radioButton2.Checked)
                        MessageBox.Show(string.Format($"{rez.num1}\n{rez.num2}\n" + rez.trig(rez.umn(a, b, a2, b2))));
                    if (radioButton3.Checked)
                        MessageBox.Show(string.Format($"{rez.num1}\n{rez.num2}\n" + rez.ecspo(rez.umn(a, b, a2, b2))));
                    break;
                case 3:
                    step = Convert.ToInt32(textBox5.Text);
                    rez.num1 = "" + Math.Pow(a, step) + "+" + Math.Pow(b, step);
                    MessageBox.Show(string.Format($"{rez.num1}\n" + rez.num1));
                    break;
                case 4:
                    if(radioButton1.Checked)
                    MessageBox.Show(string.Format($"{rez.num1}\n{rez.num2}\n" + rez.sum(a, b, a2, b2)));
                    if(radioButton2.Checked)
                        MessageBox.Show(string.Format($"{rez.num1}\n{rez.num2}\n" + rez.trig(rez.sum(a, b, a2, b2))));
                    if (radioButton3.Checked)
                        MessageBox.Show(string.Format($"{rez.num1}\n{rez.num2}\n" + rez.ecspo(rez.sum(a, b, a2, b2))));
                    break;
            }
        }
    }

    public class Kompl
    {
        public string num1;
        public string num2;
        public string answ;

        
        public string trig(string primer)
        {
            answ.Replace(',', '.');
            double a3 = Convert.ToDouble(answ.Substring(0,answ.IndexOf('+')));
            double b3 = Convert.ToDouble(answ.Substring(answ.IndexOf('i')+1));
            double fi=Math.Round(a3/Math.Sqrt(Math.Pow(a3, 2)+Math.Pow(b3,2)),4);
            double fi_sin = Math.Round(b3 / Math.Sqrt(Math.Pow(a3, 2) + Math.Pow(b3, 2)),4);
            answ = "";
            return answ = Convert.ToString((Math.Pow(a3, 2) + Math.Pow(b3, 2) + "*(" + "cos"+fi + "+i" +"sin"+fi_sin+")"));
        }
        public string ecspo(string pr)
        {
            answ.Replace(',', '.');
            double a3 = Convert.ToDouble(answ.Substring(0, answ.IndexOf('+')));
            double b3 = Convert.ToDouble(answ.Substring(answ.IndexOf('i') + 1));
            double fi = Math.Round(a3 / Math.Sqrt(Math.Pow(a3, 2) + Math.Pow(b3, 2)), 4);
            return answ = Convert.ToString(Math.Abs(Math.Pow(a3, 2) + Math.Pow(b3, 2)) + "*e" + "^i*" + fi);
        }
        public Kompl(double a, double b, double a2, double b2)
        {
            num1 = "" + a + "+i" + b;
            num2 = "" + a2 + "+i" + b2;
        }

        public string sum (double a,double b, double a2, double b2)
        {
            answ= "" + (a+a2) + "+i" + (b+b2);
            return answ;
        }

        public string minus (double a, double b, double a2, double b2)
        {
            answ =Convert.ToString((a - a2) + "+i" + (b - b2));
            return answ;
        }

        public string umn (double a, double b, double a2, double b2)
        {
            answ = "" + (a *a2) + "+i" + (a*b2 - a2*b);
            return answ;
        }

        public string del (double a, double b, double a2, double b2)
        {
            answ = "" + ((a * a2+b*b2)/(Math.Pow(a2,2)+ Math.Pow(b2, 2))) + "+i" + ((b * a2 - a * b2) / (Math.Pow(a2, 2) + Math.Pow(b2, 2)));
            return answ;
        }

    }
}
