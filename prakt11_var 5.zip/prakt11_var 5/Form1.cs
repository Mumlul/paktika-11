﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prakt11_var_5
{
    public partial class Form1 :Form
    {
        public Form1 ()
        {
            InitializeComponent();
        }
        int step = 1;
        private void button1_Click (object sender, EventArgs e)
        {
           
            
        }
        
      
        private void comboBox1_SelectedIndexChanged (object sender, EventArgs e)
        {
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                case 1:
                case 2:
                case 4:
                    label5.Visible = false;
                    textBox5.Visible = false;
                    label4.Visible = true;
                    textBox4.Visible = true;
                    label3.Visible = true;
                    textBox3.Visible = true;
                    break;
                case 3:label5.Visible = true;
                    textBox5.Visible = true;
                    label4.Visible = false;
                    textBox4.Visible = false;
                    label3.Visible = false;
                    textBox3.Visible = false;
                    break;
            }
        }

        private void button1_Click_1 (object sender, EventArgs e)
        {
            double a = Convert.ToDouble(textBox1.Text);
            double b = Convert.ToDouble(textBox2.Text);
            double a2 = Convert.ToDouble(textBox4.Text);
            double b2 = Convert.ToDouble(textBox3.Text);
            Kompl rez = new Kompl();
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    MessageBox.Show(string.Format("" + rez.minus(a, b, a2, b2)));
                    break;
                case 1:
                    MessageBox.Show(string.Format("" + rez.del(a, b, a2, b2)));
                    break;
                case 2:
                    MessageBox.Show(string.Format("" + rez.umn(a, b, a2, b2)));
                    break;
                case 3:
                    step = Convert.ToInt32(textBox5.Text);
                    rez.num1 = "" + Math.Pow(a, step) + "+" + Math.Pow(b, step);
                    MessageBox.Show(string.Format("" + rez.num1));
                    break;
                case 4:
                    MessageBox.Show(string.Format("" + rez.sum(a, b, a2, b2)));
                    break;
            }
        }
    }

    public class Kompl
    {
        public string num1;
        public string num2;
        public string answ;

        public string sum (double a,double b, double a2, double b2)
        {
            num1 = "" + a + "+i" + b;
            num2 = "" + a2 + "+i" + b2;
            answ= "" + (a+a2) + "+i" + (b+b2);
            return answ;
        }

        public string minus (double a, double b, double a2, double b2)
        {
            num1 = "" + a + "+i" + b;
            num2 = "" + a2 + "+i" + b2;
            answ = "" + (a - a2) + "+i" + (b - b2);
            return answ;
        }

        public string umn (double a, double b, double a2, double b2)
        {
            num1 = "" + a + "+i" + b;
            num2 = "" + a2 + "+i" + b2;
            answ = "" + (a *a2) + "+i" + (a*b2 - a2*b);
            return answ;
        }

        public string del (double a, double b, double a2, double b2)
        {
            num1 = "" + a + "+i" + b;
            num2 = "" + a2 + "+i" + b2;
            answ = "" + ((a * a2+b*b2)/(Math.Pow(a2,2)+ Math.Pow(b2, 2))) + "+i" + ((b * a2 - a * b2) / (Math.Pow(a2, 2) + Math.Pow(b2, 2)));
            return answ;
        }

    }
}
